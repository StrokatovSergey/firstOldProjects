let modal = document.querySelector('.modal');

document.querySelector('.header__btn').onclick = function () {
    modal.style.display = 'flex';
}

document.querySelector('.modal__close').onclick = function () {
    modal.style.display = 'none';
}

$('.slider__container').slick({
    infinite: true,
    slidesToShow: 3,
    slidesToScroll: 1,
    prevArrow: $('.prevArrow'),
    nextArrow: $('.nextArrow'),
    variableWidth: true,
    autoplay: true
    //autoplay: true
  });
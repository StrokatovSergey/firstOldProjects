$("#form-get-designer").validate({
    errorPlacement: function(label, element) {
        label.addClass('invalid-label');
        label.insertAfter(element);
    },
    wrapper: 'span',
    rules: {
        username: {
            required: true,
            minlength: 2
        }
    },
    messages: {
        username : {
            required: "Укажите имя",
            minlength: jQuery.validator.format("осталось символов {0}")
        },
        phone: "Введите корректный телефон"
    }
});
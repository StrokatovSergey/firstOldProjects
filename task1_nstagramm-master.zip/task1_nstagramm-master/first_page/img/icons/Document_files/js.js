var app = new Vue({
    el: '#app',
    data: {
        myMessage: 'привет всем'
    }
})

var app2 = new Vue({
    el: '#app2',
    data: {
        meaning: `вы загрузили страницу ${new Date().toLocaleString()}`
    }
})

var app3 = new Vue({
    el: '#app-3',
    data: {
        see: true
    }
})

var app4 = new Vue({
    el: '#ex',
    data: {
        items: [
            {ms: 'FOO'},
            {ms: 'BAAR'}
        ]
    }
})
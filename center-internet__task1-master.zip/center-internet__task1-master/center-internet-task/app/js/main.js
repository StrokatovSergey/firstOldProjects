
jQuery(document).ready(function($) {
    $('.item').magnificPopup({
        type: 'image',
        mainClass: 'my-mfp',
        zoom: {
            enabled: true, 
            duration: 400, 
            easing: 'ease-in-out', 
            opener: function(openerElement) {

              return openerElement.is('img') ? openerElement : openerElement.find('img');
            }
          }
        
    });

    
    
});

let img = document.querySelectorAll('.main__wrapper-item a');
let plus = 1;
for (let index = 0; index < img.length; index++) {
  const element = img[index];
  element.setAttribute('title', `картинка № ${plus+index}`)
  
}


